package com.cg.ibs.investment.dao;

public enum Description {
	GOLD,SILVER,MUTUAL_FUND

}
