package com.cg.ibs.investment.dao;

import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.investment.bean.*;
import com.cg.ibs.investment.exception.IBSException;

public interface BankDao {
	boolean updateGoldPrice(double x) throws IBSException;

	boolean updateSilverPrice(double y) throws IBSException;

	boolean addMF(BankMutualFund mutualFund) throws IBSException;

	CustomerBean getBankAdmin(String userid) throws IBSException;
}
