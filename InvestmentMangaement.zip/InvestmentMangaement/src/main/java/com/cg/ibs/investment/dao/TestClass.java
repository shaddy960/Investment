package com.cg.ibs.investment.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.cg.ibs.common.bean.AccountBean;
import com.cg.ibs.common.bean.CustomerBean;
import com.cg.ibs.common.bean.TransactionBean;
import com.cg.ibs.common.bean.TransactionType;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.exception.ErrorMessages;
import com.cg.ibs.investment.exception.IBSException;

public class TestClass {

	public static void main(String[] args) throws IBSException {
		


		boolean status = false;

		try (Connection con = ConnectionProvider.getInstance().getConnection();
				PreparedStatement pst1 = con.prepareStatement(QueryMapper.UPDATE_GOLD_PRICE);
				PreparedStatement pst2 = con.prepareStatement(QueryMapper.GET_MAX_UPDATE_DATE);) {
			pst2.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			ResultSet rs = pst2.executeQuery();
			
			if(!rs.next()) {	
			pst1.setDate(1, java.sql.Date.valueOf(LocalDate.now()));

		
			pst1.setDouble(2, 3000);
			pst1.executeUpdate();
			status = true;
			}

			
		} catch (SQLException | IOException e) {
			
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}
	System.out.println( status);

	}
}