package com.cg.customerservice;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.BankService;
import com.cg.ibs.investment.service.BankServiceImpl;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;

class CustomerServiceImplTest {

	CustomerService customertService;
	BankService bankService;
	InvestmentBean investmentBean;
	CustomerDao clientDao;

	@BeforeEach
	void doit() {
		customertService = new CustomerServiceImpl();
		bankService = new BankServiceImpl();
		investmentBean = new InvestmentBean("slow5567", "pqr888");
		clientDao = new InvestmentDaoImpl();

	}

	@Nested
	@DisplayName("Testing Buy Gold Method")
	class BuyGold {
		CustomerService customerService = new CustomerServiceImpl();

		@Test
		@DisplayName("Buy Gold Balance Positive")
		void testGoldBalanceUnits() {

			try {
				double goldPrice = customerService.viewGoldPrice();
				double initialgu = customerService.viewInvestments("slow5567").getGoldunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.buyGold(3, "slow5567");

				double finalgu = customerService.viewInvestments("slow5567").getGoldunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertEquals(finalgu - initialgu, 3),
						() -> assertEquals(initialb - finalb, 3 * goldPrice));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Buy Gold Balance Negative")
		void testGoldBalanceUnits2() {
			try {
				double initialgu = customerService.viewInvestments("slow5567").getGoldunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.buyGold(2, "slow5567");

				double finalgu = customerService.viewInvestments("slow5567").getGoldunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertNotEquals(finalgu - initialgu, 5),
						() -> assertNotEquals(finalb - initialb, 40000));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Buy Gold Exceptions")
		void testGoldBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(100, "slow5567");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.buyGold(-10, "slow5567");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Buy Silver Method")
	class BuySilver {
		CustomerService customerService = new CustomerServiceImpl();

		@Test
		@DisplayName("Buy Silver Balance Positive")
		void testSilverBalanceUnits() {

			try {
				double initialsu = customerService.viewInvestments("slow5567").getSilverunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				double silverPrice = customerService.viewSilverPrice();
				customerService.buySilver(5, "slow5567");

				double finalsu = customerService.viewInvestments("slow5567").getSilverunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertEquals(finalsu - initialsu, 5),
						() -> assertEquals(initialb - finalb, 5 * silverPrice));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Buy Silver Balance Negative")
		void testSilverdBalanceUnits2() {
			try {
				double initialsu = customerService.viewInvestments("slow5567").getSilverunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.buySilver(5, "slow5567");

				double finalsu = customerService.viewInvestments("slow5567").getSilverunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertNotEquals(finalsu - initialsu, 3),
						() -> assertNotEquals(initialb - finalb, 30000));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Buy Silver Exceptions")
		void testSilverBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.buySilver(100000, "slow5567");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.buySilver(-10, "slow5567");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Sell Gold Method")
	class SellGold {
		CustomerService customerService = new CustomerServiceImpl();

		@Test
		@DisplayName("Sell Gold Balance Positive")
		void testGoldBalanceUnits() {

			try {
				double goldPrice = customerService.viewGoldPrice();
				double initialgu = customerService.viewInvestments("slow5567").getGoldunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.sellGold(4, "slow5567");

				double finalgu = customerService.viewInvestments("slow5567").getGoldunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertEquals(initialgu - finalgu, 4),
						() -> assertEquals(finalb - initialb, 4 * goldPrice));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Sell Gold Balance Negative")
		void testGoldBalanceUnits2() {
			try {
				double goldPrice = customerService.viewGoldPrice();
				double initialgu = customerService.viewInvestments("slow5567").getGoldunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.sellGold(5, "slow5567");

				double finalgu = customerService.viewInvestments("slow5567").getGoldunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertNotEquals(initialgu - finalgu, 20),
						() -> assertNotEquals(finalb - initialb, 10 * goldPrice));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Sell Gold Exceptions")
		void testGoldBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.sellGold(10000, "slow5567");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.sellGold(-10, "slow5567");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Sdell Silver Method")
	class SellSilver {
		CustomerService customerService = new CustomerServiceImpl();

		@Test
		@DisplayName("Sell Silver Balance Positive")
		void testSilverBalanceUnits() {

			try {
				double initialsu = customerService.viewInvestments("slow5567").getSilverunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				double silverPrice = customerService.viewSilverPrice();
				customerService.sellSilver(5, "slow5567");

				double finalsu = customerService.viewInvestments("slow5567").getSilverunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertEquals(initialsu - finalsu, 5),
						() -> assertEquals(finalb - initialb, 5 * silverPrice));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Sell Silver Balance Negative")
		void testSilverdBalanceUnits2() {
			try {
				double initialsu = customerService.viewInvestments("slow5567").getSilverunits();
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customerService.sellSilver(5, "slow5567");

				double finalsu = customerService.viewInvestments("slow5567").getSilverunits();
				double finalb = customerService.viewInvestments("slow5567").getBalance();
				assertAll(() -> assertNotEquals(finalsu - initialsu, 30),
						() -> assertNotEquals(finalb - initialb, 6200000));
			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Sell Silver Exceptions")
		void testSilverBalanceUnits3() {

			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.sellSilver(100000, "slow5567");
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.sellSilver(-10, "slow5567");
			}));
		}
	}

	@Nested
	@DisplayName("Testing Invest MF Method")
	class InvestMF {
		@Test
		@DisplayName("Invest MF Positive")
		void testInvestMF() {
			CustomerService customerService = new CustomerServiceImpl();
			CustomerDao customerDao = new InvestmentDaoImpl();

			try {
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customertService.investMF(2000, "slow5567", 10001);
				double finalb = customerService.viewInvestments("slow5567").getBalance();

				assertEquals(initialb - finalb, 2000);
				assertNotNull(customerDao.viewInvestments("5555111151513301").getFunds());

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Invest MF Negative")
		void testInvestMF2() {
			CustomerService customerService = new CustomerServiceImpl();
			CustomerDao customerDao = new InvestmentDaoImpl();

			try {
				double initialb = customerService.viewInvestments("slow5567").getBalance();
				customertService.investMF(2000, "slow5567", 10001);
				double finalb = customerService.viewInvestments("slow5567").getBalance();

				assertNotEquals(initialb - finalb, 2000);

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Invest MF Exceptions")
		void testInvestMF3() {
			CustomerService customerService = new CustomerServiceImpl();
			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.investMF(200000, "slow5567", 10001);
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.investMF(-1000, "slow5567", 10001);
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.investMF(10000, "slow5567", 10009);
			})

			);
		}

	}

	@Nested
	@DisplayName("Testing Withdraw MF Method")
	class WithdrawMF {
		@Test
		@DisplayName("Withdraw MF Positive")
		void testWithdrawMF() {
			CustomerService customerService = new CustomerServiceImpl();
			CustomerDao customerDao = new InvestmentDaoImpl();

			try {

				assertNotNull(customerService.viewInvestments("slow5567").getFunds());

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Withdraw MF Negative")
		void testWithdrawMF2() {
			CustomerService customerService = new CustomerServiceImpl();

			try {
				assertNotNull(customerService.viewInvestments("slow5567").getFunds());

			} catch (IBSException e) {
				assertNotNull(e);
			}

		}

		@Test
		@DisplayName("Withdraw MF Exceptions")
		void testWithdrawMF3() {
			CustomerService customerService = new CustomerServiceImpl();
			assertAll(() -> assertThrows(IBSException.class, () -> {
				customerService.investMF(200000, "slow5567", 10001);
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.investMF(-1000, "slow5567", 10001);
			}), () -> assertThrows(IBSException.class, () -> {
				customerService.investMF(10000, "slow5567", 10009);
			})

			);
		}
	}

	@Test
	@DisplayName("View MF")
	void testViewtMF() {
		CustomerService customerService = new CustomerServiceImpl();
		assertAll(() -> assertNotNull(customerService.viewInvestments("slow5567").getBalance()),
				() -> assertNotNull(customerService.viewInvestments("slow5567").getGoldunits()),
				() -> assertNotNull(customerService.viewInvestments("slow5567").getSilverunits()),
				() -> assertNotNull(customerService.viewInvestments("slow5567").getFunds()));
	}

	@Test
	@DisplayName("View Gold Price")
	void testViewGoldPrice() {

		CustomerService customerService = new CustomerServiceImpl();
		try {
			assertNotNull(customertService.viewGoldPrice());
		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

	@Test
	@DisplayName("View Silver Price")
	void testViewSilverPrice() {

		CustomerService customerService = new CustomerServiceImpl();
		try {
			assertNotNull(customertService.viewSilverPrice());
		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

}
