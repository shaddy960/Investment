package com.cg.ibs.investment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BankMutualFund {
	@Id
	private Integer mfPlanId; 
	private String title; 
	@Column(precision = 2)
	private Double nav;
	public BankMutualFund() {
		super();
	}
	public Integer getMfPlanId() {
		return mfPlanId;
	}
	public void setMfPlanId(Integer mfPlanId) {
		this.mfPlanId = mfPlanId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Double getNav() {
		return nav;
	}
	public void setNav(Double nav) {
		this.nav = nav;
	}
	
	
}
