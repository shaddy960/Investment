package com.cg.ibs.investment.bean;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="transaction_extended")
@NamedQueries({
	@NamedQuery(name="getTransactions",query="select c from InvestmentTransaction c where c.accountNumber=?1")
	
})
public class InvestmentTransaction extends TransactionBean {
	@Column(name = "units", precision = 2)
	private Double units;
	@Column(name = "price_per_unit", precision = 2)
	private Double pricePerUnit;
	public InvestmentTransaction() {
		super();
	}
	public Double getUnits() {
		return units;
	}
	public void setUnits(Double units) {
		this.units = units;
	}
	public Double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(Double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	@Override
	public String toString() {
		return "InvestmentTransaction [units=" + units + ", pricePerUnit=" + pricePerUnit + ", toString()="
				+ super.toString() + "]";
	}
	

}
