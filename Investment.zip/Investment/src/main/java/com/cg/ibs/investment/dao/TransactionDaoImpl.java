package com.cg.ibs.investment.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.cg.ibs.investment.bean.TransactionBean;
import com.cg.ibs.investment.util.JPAUtil;

public class TransactionDaoImpl implements TransactionDao {
	private EntityManager entityManager;

	public TransactionDaoImpl() {
		entityManager = JPAUtil.getEntityManger();
	}
	@Override
	public TransactionBean addTransaction(TransactionBean trxn) {
		entityManager.persist(trxn);
		return trxn;
	}

	@Override
	public List<TransactionBean> getAllTransactionByAccno(BigInteger accno) {
		CriteriaQuery<TransactionBean> query = entityManager.getCriteriaBuilder().createQuery(TransactionBean.class);
		Root<TransactionBean> root = query.from(TransactionBean.class);
		query.select(root);

		return entityManager.createQuery(query).getResultList();
	}

}
