package com.cg.ibs.investment.service;

import javax.persistence.EntityTransaction;

import com.cg.ibs.investment.bean.AccountBean;
import com.cg.ibs.investment.bean.AccountHoldingBean;
import com.cg.ibs.investment.bean.BankAdmins;
import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.bean.CustomerBean;
import com.cg.ibs.investment.bean.InvestmentBean;
import com.cg.ibs.investment.bean.MutualFund;
import com.cg.ibs.investment.bean.TransactionBean;
import com.cg.ibs.investment.dao.AccHoldDao;
import com.cg.ibs.investment.dao.AccHoldDaoImpl;
import com.cg.ibs.investment.dao.AccountDao;
import com.cg.ibs.investment.dao.AccountDaoImpl;
import com.cg.ibs.investment.dao.BankAdminsDao;
import com.cg.ibs.investment.dao.BankAdminsDaoImpl;
import com.cg.ibs.investment.dao.BankMutualFundDao;
import com.cg.ibs.investment.dao.BankMutualFundDaoImpl;
import com.cg.ibs.investment.dao.CustomerDao;
import com.cg.ibs.investment.dao.CustomerDaoImpl;
import com.cg.ibs.investment.dao.GoldPriceDao;
import com.cg.ibs.investment.dao.GoldPriceDaoImpl;
import com.cg.ibs.investment.dao.InvestmentDao;
import com.cg.ibs.investment.dao.InvestmentDaoImpl;
import com.cg.ibs.investment.dao.MutualFundDao;
import com.cg.ibs.investment.dao.MutualFundDaoImpl;
import com.cg.ibs.investment.dao.SilverPriceDao;
import com.cg.ibs.investment.dao.SilverPriceDaoImpl;
import com.cg.ibs.investment.dao.TransactionDao;
import com.cg.ibs.investment.dao.TransactionDaoImpl;
import com.cg.ibs.investment.util.JPAUtil;

public class AdditionService {
private CustomerDao custDao;
private AccountDao accountDao;
private SilverPriceDao silverPriceDao;
private GoldPriceDao goldPriceDao;
private InvestmentDao investmentDao;
private TransactionDao transactionDao;
private MutualFundDao mutualFundDao;
private BankMutualFundDao bankMutualFundDao;
private BankAdminsDao bankAdminsDao;
private AccHoldDao accHoldDao;
	
	public AdditionService() {
		custDao=new CustomerDaoImpl();
		accountDao=new AccountDaoImpl();
		silverPriceDao=new SilverPriceDaoImpl();
		goldPriceDao=new GoldPriceDaoImpl();
		investmentDao=new InvestmentDaoImpl();
		transactionDao=new TransactionDaoImpl();
		mutualFundDao=new MutualFundDaoImpl();
		bankMutualFundDao=new BankMutualFundDaoImpl();
		bankAdminsDao=new BankAdminsDaoImpl();
		accHoldDao=new AccHoldDaoImpl();
	}
	
	public CustomerBean addCustomer(CustomerBean cust) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		CustomerBean savedCustomerBean=custDao.addCustomer(cust);
		txn.commit();
		return savedCustomerBean;
	}
	public AccountBean addAccount(AccountBean account) {
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		AccountBean savedBean=accountDao.addAccount(account);
		txn.commit();
		return savedBean;
	}
	public TransactionBean addTransaction(TransactionBean bean) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		TransactionBean savedBean=transactionDao.addTransaction(bean);
		txn.commit();
		return savedBean;
	}
	/*public GoldPrice addGoldPrice(GoldPrice price) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		GoldPrice savedBean=goldPriceDao.addGoldPrice(price);
		txn.commit();
		return savedBean;
		
	}
	
	public SilverPrice addSilverPrice(SilverPrice price) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		SilverPrice savedBean=silverPriceDao.addSilverPrice(price);
		txn.commit();
		return savedBean;
	}
	*/
	public MutualFund addMutualFund(MutualFund mf) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		MutualFund savedBean=mutualFundDao.addMutualFund(mf);
		txn.commit();
		return savedBean;
	}
	public BankMutualFund addBankMutualFund(BankMutualFund fund) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		BankMutualFund savedBean=bankMutualFundDao.addBankMutFund(fund);
		txn.commit();
		return savedBean;
	}
	public InvestmentBean addInvestment(InvestmentBean inv) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		InvestmentBean savedBean=investmentDao.addInvestment(inv);
		txn.commit();
		return savedBean;
	}
	public BankAdmins addBankadAdmins(BankAdmins ad) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		BankAdmins savedBean=bankAdminsDao.addBankAdmins(ad);
		txn.commit();
		return savedBean;
	}
	public AccountHoldingBean addAccHold(AccountHoldingBean accHold) {
		//after validations
		EntityTransaction txn = JPAUtil.getTransaction();
		txn.begin();
		AccountHoldingBean savedBean=accHoldDao.addAccountHold(accHold);
		txn.commit();
		return savedBean;
	}
	
	
}
