package com.cg.ibs.investment.bean;

public enum TransactionType {
	CREDIT,DEBIT
}
