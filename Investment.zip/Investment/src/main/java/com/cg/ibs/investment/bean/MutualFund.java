package com.cg.ibs.investment.bean;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

@Entity
public class MutualFund {
	@Id
	private Integer mfid;
	@OneToOne
	private BankMutualFund bankMutualFund;
	@Column(precision = 2)		
	private Double mfUnits;
	@Column(precision = 2)
	private Double mfAmount;		
	private LocalDate openingDate;	
	private LocalDate closingDate;	
	private Boolean status;
	@ManyToOne(cascade = CascadeType.PERSIST)
	private InvestmentBean inv;
	
	public InvestmentBean getInv() {
		return inv;
	}
	public void setInv(InvestmentBean inv) {
		this.inv = inv;
	}
	public MutualFund() {
		super();
	}
	public Integer getMfid() {
		return mfid;
	}
	public void setMfid(Integer mfid) {
		this.mfid = mfid;
	}
	public BankMutualFund getBankMutualFund() {
		return bankMutualFund;
	}
	public void setBankMutualFund(BankMutualFund bankMutualFund) {
		this.bankMutualFund = bankMutualFund;
	}
	public Double getMfUnits() {
		return mfUnits;
	}
	public void setMfUnits(Double mfUnits) {
		this.mfUnits = mfUnits;
	}
	public Double getMfAmount() {
		return mfAmount;
	}
	public void setMfAmount(Double mfAmount) {
		this.mfAmount = mfAmount;
	}
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public LocalDate getClosingDate() {
		return closingDate;
	}
	public void setClosingDate(LocalDate closingDate) {
		this.closingDate = closingDate;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
}
