package com.cg.ibs.investment.bean;

public enum TransactionMode {
	ONLINE,CASH
}
